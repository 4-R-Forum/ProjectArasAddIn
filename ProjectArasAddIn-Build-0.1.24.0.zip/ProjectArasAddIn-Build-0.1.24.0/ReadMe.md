Please read ProjectArasAddIn-ReleaseNotes-DeploymentGuide.txt for deployment and use instructions.

updated 12/19/2017